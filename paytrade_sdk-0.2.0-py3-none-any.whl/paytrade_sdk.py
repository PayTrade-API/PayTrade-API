"""PayTrade SDK: all amounts are integer Telegram Stars (XTR)."""
import asyncio
import time
from dataclasses import dataclass
from urllib.parse import quote, urlparse

import aiohttp

__version__ = '0.2.0'
__all__ = ['PayTrade', 'Payment', 'PayTradeError']


class PayTradeError(Exception):
    def __init__(self, code, message, status=0):
        self.code, self.status = code, status
        super().__init__(message)


@dataclass(frozen=True)
class Payment:
    id: str
    order_id: str
    buyer_id: int
    amount: int
    currency: str
    title: str
    description: str
    status: str
    created_at: int
    expires_at: int
    paid_at: int | None
    payment_url: str
    test_mode: bool = False

    @property
    def paid(self):
        return self.status == 'paid'


class PayTrade:
    def __init__(self, api_key: str, base_url: str, *, timeout: float = 15,
                 session: aiohttp.ClientSession | None = None):
        parsed = urlparse(base_url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.query or parsed.fragment or parsed.username or parsed.password:
            raise ValueError('base_url must be an HTTP(S) origin or prefix without credentials/query/fragment')
        if parsed.scheme == 'http' and parsed.hostname not in ('localhost', '127.0.0.1', '::1'):
            raise ValueError('Use HTTPS for a remote API; HTTP is allowed only on localhost')
        if not api_key or timeout <= 0:
            raise ValueError('api_key and a positive timeout are required')
        self._key = api_key
        self.base_url = base_url.rstrip('/')
        self.timeout = aiohttp.ClientTimeout(total=timeout)
        self._session, self._owns_session = session, session is None

    async def __aenter__(self):
        return self

    async def __aexit__(self, *exc):
        await self.close()

    async def close(self):
        if self._owns_session and self._session is not None:
            await self._session.close()
            self._session = None

    async def _request(self, method, path, data=None):
        if self._session is None:
            self._session = aiohttp.ClientSession()
        try:
            async with self._session.request(
                method, self.base_url + path, json=data,
                headers={'Authorization': 'Bearer ' + self._key},
                timeout=self.timeout, allow_redirects=False,
            ) as response:
                try:
                    body = await response.json()
                except (ValueError, aiohttp.ContentTypeError):
                    raise PayTradeError('invalid_response', 'API returned a non-JSON response', response.status) from None
                if not 200 <= response.status < 300:
                    error = body.get('error', {}) if isinstance(body, dict) else {}
                    raise PayTradeError(error.get('code', 'http_error'), error.get('message', 'API error'), response.status)
                return body
        except (aiohttp.ClientError, asyncio.TimeoutError):
            raise PayTradeError('network_error', 'Cannot reach PayTrade API; retry creation with the SAME order_id') from None

    async def me(self):
        return await self._request('GET', '/v1/me')

    async def create_payment(self, *, order_id: str, buyer_id: int, amount: int,
                             title: str, description: str = '', return_payload: str = '',
                             expires_in: int = 3600) -> Payment:
        """order_id is an idempotency key, unique inside this application."""
        body = await self._request('POST', '/v1/payments', {
            'order_id': order_id, 'buyer_id': buyer_id, 'amount': amount,
            'title': title, 'description': description,
            'return_payload': return_payload, 'expires_in': expires_in})
        return Payment(**body)

    async def payment(self, title: str, amount: int, *, buyer_id: int, order_id: str,
                      description: str = '', return_payload: str = '', expires_in: int = 3600) -> Payment:
        """One-line configuration: await api.payment('Title', price, buyer_id=uid, order_id=order).

        amount may be a constant or a validated runtime value. Mode is configured
        in the service bot, returned as Payment.test_mode and frozen per invoice.
        """
        return await self.create_payment(order_id=order_id, buyer_id=buyer_id, amount=amount,
            title=title, description=description, return_payload=return_payload, expires_in=expires_in)

    async def get_payment(self, payment_id: str) -> Payment:
        return Payment(**await self._request('GET', '/v1/payments/' + quote(payment_id, safe='')))

    async def cancel_payment(self, payment_id: str) -> Payment:
        return Payment(**await self._request('POST', '/v1/payments/' + quote(payment_id, safe='') + '/cancel'))

    async def wait_for_payment(self, payment_id: str, *, timeout: float = 300, interval: float = 3) -> Payment:
        """Convenience polling for a few orders; not a durable background worker.

        Returns paid/cancelled/expired. Raises TimeoutError if still pending/processing.
        For many payments implement a bounded worker respecting 120 requests/min/app.
        """
        if timeout <= 0 or interval < 1:
            raise ValueError('timeout must be positive and interval >= 1')
        deadline = time.monotonic() + timeout
        while True:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise TimeoutError('Payment remains pending; it has NOT been cancelled')
            payment = await asyncio.wait_for(self.get_payment(payment_id), timeout=remaining)
            if payment.status in ('paid', 'cancelled', 'expired'):
                return payment
            await asyncio.sleep(min(interval, max(0, deadline - time.monotonic())))
